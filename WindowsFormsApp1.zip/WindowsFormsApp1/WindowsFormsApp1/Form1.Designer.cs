﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkSearchID = new System.Windows.Forms.CheckBox();
            this.dtpDate = new System.Windows.Forms.DateTimePicker();
            this.dtpTime = new System.Windows.Forms.DateTimePicker();
            this.tbID = new System.Windows.Forms.TextBox();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.dtpBeginDate = new System.Windows.Forms.DateTimePicker();
            this.dtpBeginTime = new System.Windows.Forms.DateTimePicker();
            this.dtpEndTime = new System.Windows.Forms.DateTimePicker();
            this.btnSimSwipe = new System.Windows.Forms.Button();
            this.tbSearchID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkFromDate = new System.Windows.Forms.CheckBox();
            this.chkToDate = new System.Windows.Forms.CheckBox();
            this.chkFromTime = new System.Windows.Forms.CheckBox();
            this.chkToTime = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // chkSearchID
            // 
            this.chkSearchID.AutoSize = true;
            this.chkSearchID.Location = new System.Drawing.Point(382, 148);
            this.chkSearchID.Name = "chkSearchID";
            this.chkSearchID.Size = new System.Drawing.Size(74, 17);
            this.chkSearchID.TabIndex = 0;
            this.chkSearchID.Text = "Search ID";
            this.chkSearchID.UseVisualStyleBackColor = true;
            this.chkSearchID.CheckedChanged += new System.EventHandler(this.chkEnable_CheckedChanged);
            // 
            // dtpDate
            // 
            this.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDate.Location = new System.Drawing.Point(385, 38);
            this.dtpDate.Name = "dtpDate";
            this.dtpDate.Size = new System.Drawing.Size(196, 20);
            this.dtpDate.TabIndex = 1;
            // 
            // dtpTime
            // 
            this.dtpTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpTime.Location = new System.Drawing.Point(385, 64);
            this.dtpTime.Name = "dtpTime";
            this.dtpTime.Size = new System.Drawing.Size(196, 20);
            this.dtpTime.TabIndex = 2;
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(385, 12);
            this.tbID.Name = "tbID";
            this.tbID.Size = new System.Drawing.Size(196, 20);
            this.tbID.TabIndex = 4;
            // 
            // dataGrid
            // 
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(12, 12);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.Size = new System.Drawing.Size(364, 257);
            this.dataGrid.TabIndex = 5;
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.Enabled = false;
            this.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEndDate.Location = new System.Drawing.Point(458, 200);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(164, 20);
            this.dtpEndDate.TabIndex = 7;
            this.dtpEndDate.ValueChanged += new System.EventHandler(this.dtpEndDate_ValueChanged);
            // 
            // dtpBeginDate
            // 
            this.dtpBeginDate.Enabled = false;
            this.dtpBeginDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpBeginDate.Location = new System.Drawing.Point(458, 174);
            this.dtpBeginDate.Name = "dtpBeginDate";
            this.dtpBeginDate.Size = new System.Drawing.Size(164, 20);
            this.dtpBeginDate.TabIndex = 6;
            this.dtpBeginDate.ValueChanged += new System.EventHandler(this.dtpBeginDate_ValueChanged);
            // 
            // dtpBeginTime
            // 
            this.dtpBeginTime.Enabled = false;
            this.dtpBeginTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpBeginTime.Location = new System.Drawing.Point(458, 226);
            this.dtpBeginTime.Name = "dtpBeginTime";
            this.dtpBeginTime.Size = new System.Drawing.Size(164, 20);
            this.dtpBeginTime.TabIndex = 8;
            this.dtpBeginTime.ValueChanged += new System.EventHandler(this.dtpBeginTime_ValueChanged);
            // 
            // dtpEndTime
            // 
            this.dtpEndTime.Enabled = false;
            this.dtpEndTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpEndTime.Location = new System.Drawing.Point(458, 252);
            this.dtpEndTime.Name = "dtpEndTime";
            this.dtpEndTime.Size = new System.Drawing.Size(164, 20);
            this.dtpEndTime.TabIndex = 9;
            this.dtpEndTime.ValueChanged += new System.EventHandler(this.dtpEndTime_ValueChanged);
            // 
            // btnSimSwipe
            // 
            this.btnSimSwipe.Location = new System.Drawing.Point(385, 91);
            this.btnSimSwipe.Name = "btnSimSwipe";
            this.btnSimSwipe.Size = new System.Drawing.Size(196, 23);
            this.btnSimSwipe.TabIndex = 14;
            this.btnSimSwipe.Text = "Simulate Swipe";
            this.btnSimSwipe.UseVisualStyleBackColor = true;
            this.btnSimSwipe.Click += new System.EventHandler(this.btnSimSwipe_Click_1);
            // 
            // tbSearchID
            // 
            this.tbSearchID.Enabled = false;
            this.tbSearchID.Location = new System.Drawing.Point(458, 148);
            this.tbSearchID.Name = "tbSearchID";
            this.tbSearchID.Size = new System.Drawing.Size(164, 20);
            this.tbSearchID.TabIndex = 15;
            this.tbSearchID.TextChanged += new System.EventHandler(this.tbSearchID_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(382, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Filters:";
            // 
            // chkFromDate
            // 
            this.chkFromDate.AutoSize = true;
            this.chkFromDate.Location = new System.Drawing.Point(382, 174);
            this.chkFromDate.Name = "chkFromDate";
            this.chkFromDate.Size = new System.Drawing.Size(49, 17);
            this.chkFromDate.TabIndex = 17;
            this.chkFromDate.Text = "From";
            this.chkFromDate.UseVisualStyleBackColor = true;
            this.chkFromDate.CheckedChanged += new System.EventHandler(this.chkFromDate_CheckedChanged);
            // 
            // chkToDate
            // 
            this.chkToDate.AutoSize = true;
            this.chkToDate.Location = new System.Drawing.Point(382, 200);
            this.chkToDate.Name = "chkToDate";
            this.chkToDate.Size = new System.Drawing.Size(39, 17);
            this.chkToDate.TabIndex = 18;
            this.chkToDate.Text = "To";
            this.chkToDate.UseVisualStyleBackColor = true;
            this.chkToDate.CheckedChanged += new System.EventHandler(this.chkToDate_CheckedChanged);
            // 
            // chkFromTime
            // 
            this.chkFromTime.AutoSize = true;
            this.chkFromTime.Location = new System.Drawing.Point(382, 226);
            this.chkFromTime.Name = "chkFromTime";
            this.chkFromTime.Size = new System.Drawing.Size(49, 17);
            this.chkFromTime.TabIndex = 19;
            this.chkFromTime.Text = "From";
            this.chkFromTime.UseVisualStyleBackColor = true;
            this.chkFromTime.CheckedChanged += new System.EventHandler(this.chkFromTime_CheckedChanged);
            // 
            // chkToTime
            // 
            this.chkToTime.AutoSize = true;
            this.chkToTime.Location = new System.Drawing.Point(382, 252);
            this.chkToTime.Name = "chkToTime";
            this.chkToTime.Size = new System.Drawing.Size(39, 17);
            this.chkToTime.TabIndex = 20;
            this.chkToTime.Text = "To";
            this.chkToTime.UseVisualStyleBackColor = true;
            this.chkToTime.CheckedChanged += new System.EventHandler(this.chkToTime_CheckedChanged);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(633, 290);
            this.Controls.Add(this.chkToTime);
            this.Controls.Add(this.chkFromTime);
            this.Controls.Add(this.chkToDate);
            this.Controls.Add(this.chkFromDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbSearchID);
            this.Controls.Add(this.btnSimSwipe);
            this.Controls.Add(this.dtpEndTime);
            this.Controls.Add(this.dtpBeginTime);
            this.Controls.Add(this.dtpEndDate);
            this.Controls.Add(this.dtpBeginDate);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.tbID);
            this.Controls.Add(this.dtpTime);
            this.Controls.Add(this.dtpDate);
            this.Controls.Add(this.chkSearchID);
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkSearchID;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.DateTimePicker dtpTime;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.DateTimePicker dtpBeginDate;
        private System.Windows.Forms.DateTimePicker dtpBeginTime;
        private System.Windows.Forms.DateTimePicker dtpEndTime;
        private System.Windows.Forms.Button btnSimSwipe;
        private System.Windows.Forms.TextBox tbSearchID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkFromDate;
        private System.Windows.Forms.CheckBox chkToDate;
        private System.Windows.Forms.CheckBox chkFromTime;
        private System.Windows.Forms.CheckBox chkToTime;
    }
}

