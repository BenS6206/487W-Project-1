﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Ben_S_000\source\repos\WindowsFormsApp1\WindowsFormsApp1\swipes.mdf;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
            fillTable();
        }

        private void fillTable()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {

                    connection.Open();
                    String queryString= "SELECT Id, Time, Date From SWIPES ";
                    if (chkSearchID.Checked || chkFromTime.Checked || chkToTime.Checked || chkFromDate.Checked || chkToDate.Checked)
                    {
                        if ((chkSearchID.Checked && tbSearchID.Text != "") || chkSearchID.Checked == false) 
                            {
                            queryString = queryString + "where ";
                            }
                        if (chkSearchID.Checked && tbSearchID.Text != "")
                        {
                            queryString = queryString + "ID=" + tbSearchID.Text + " ";
                            //MessageBox.Show(queryString);
                        }
                        if (chkFromDate.Checked)
                        {
                            if(chkSearchID.Checked)
                            { queryString = queryString + "and "; }
                            queryString = queryString + "Date> '" + dtpBeginDate.Text + "' ";
                        }
                        if (chkToDate.Checked)
                        {
                            if (chkSearchID.Checked||chkFromDate.Checked)
                            { queryString = queryString + "and "; }
                            queryString = queryString + "Date< '" + dtpEndDate.Text + "' ";
                        }
                        if (chkFromTime.Checked)
                        {
                            if (chkSearchID.Checked || chkFromDate.Checked || chkToDate.Checked)
                            { queryString = queryString + "and "; }
                            queryString = queryString + "Time> '" + dtpBeginTime.Text + "' ";
                        }
                        if (chkToTime.Checked)
                        {
                            if (chkSearchID.Checked || chkFromDate.Checked || chkToDate.Checked|| chkFromTime.Checked)
                            { queryString = queryString + "and "; }
                            queryString = queryString + "Time< '" + dtpEndTime.Text + "' ";
                        }
                    }
                    SqlDataAdapter tableQuery = new SqlDataAdapter(queryString, connection);
                    DataTable table = new DataTable();
                    tableQuery.Fill(table);
                    dataGrid.DataSource = table;
                    connection.Close();
                   
                }
                catch (Exception exception)
                {
                    MessageBox.Show(exception.ToString());
                }
            }
        }

        private void btnSimSwipe_Click(object sender, EventArgs e)
        {
            //this was caused by some shenanigans where I ended up accidentally deleting a lot of progress, as to not risk that again I am leaving this here.
        }

        

        private void btnSimSwipe_Click_1(object sender, EventArgs e)
        {
            if (tbID.Text != null && dtpDate.Text != null)
            {
                //open connection
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();
                        MessageBox.Show("connection is open!");

                        //get value for swipenum for new key
                        string getSwipeNum = "SELECT MAX (Swipenum) as pp From SWIPES";

                        int newSwipeNum =0;
                        SqlCommand cmd = new SqlCommand(getSwipeNum, connection);

                        if (cmd.ExecuteScalar().ToString() != null && cmd.ExecuteScalar().ToString() != "")
                        {
                            
                            newSwipeNum = (int)cmd.ExecuteScalar() + 1;
                        }
                        cmd.Dispose();

                        //reset connection for new command
                        connection.Close();
                        connection.Open();

                        string insert = "insert into SWIPES (ID,Date,Swipenum,Time) values ('" + tbID.Text + "','" + dtpDate.Value + "','" + newSwipeNum + "','" + dtpTime.Value + "')";
                        cmd = new SqlCommand(insert, connection);
                        cmd.ExecuteNonQuery();
                        cmd.Dispose();
                        connection.Close();
                        fillTable();
                    }
                    catch (Exception exception)
                    {
                        MessageBox.Show(exception.ToString());
                    }
                }
            }
        }
        
        private void dtpBeginDate_ValueChanged(object sender, EventArgs e)
        {
            fillTable();
        }

        private void dtpEndDate_ValueChanged(object sender, EventArgs e)
        {
            fillTable();
        }

        private void dtpBeginTime_ValueChanged(object sender, EventArgs e)
        {
            fillTable();
        }

        private void dtpEndTime_ValueChanged(object sender, EventArgs e)
        {
            fillTable();
        }

        private void tbSearchID_TextChanged(object sender, EventArgs e)
        {
            fillTable();
        }

        private void chkEnable_CheckedChanged(object sender, EventArgs e)
        {
            tbSearchID.Enabled = chkSearchID.Checked;
        }

        private void chkFromDate_CheckedChanged(object sender, EventArgs e)
        {
            dtpBeginDate.Enabled = chkFromDate.Checked;

        }

        private void chkToDate_CheckedChanged(object sender, EventArgs e)
        {
            dtpEndDate.Enabled = chkToDate.Checked;

        }

        private void chkFromTime_CheckedChanged(object sender, EventArgs e)
        {
            dtpBeginTime.Enabled = chkFromTime.Checked;
        }

        private void chkToTime_CheckedChanged(object sender, EventArgs e)
        {
            dtpEndTime.Enabled = chkToTime.Checked;
        }


    }
}
